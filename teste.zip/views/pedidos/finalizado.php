<?php include __DIR__ . '/../layout/header.php'; ?>
<div class='container mt-4 alert alert-success'>Pedido <?=$pedido_id?> finalizado com sucesso!</div>
<?php include __DIR__ . '/../layout/footer.php'; ?>